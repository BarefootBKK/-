#include"MainFrame.h"
#include<windows.h>  

#include<mmsystem.h>  
#pragma comment(lib,"winmm.lib")  
#include"resource.h"

#include <QMessageBox>

MainFrame::MainFrame(QWidget *parent)
	: QWidget(parent)
{
	g = new Gobang();
	l = new Log();
	room = new Room();

	ui.setupUi(this);
	this->initData();	// ��ʼ������

	QThread * thread = new QThread();
	socket = new Socket(Q_NULLPTR, "127.0.0.1", 8080);
	connect(socket, SIGNAL(readyRead()),	socket, SLOT(on_read()));
	connect(socket, SIGNAL(connected()),	socket, SLOT(on_connection()));
	connect(socket, SIGNAL(disconnected()), socket, SLOT(on_disconnection()));
	connect(socket, SIGNAL(serv_msg(QStringList)), room, SLOT(updateRoomList(QStringList)));
	connect(l, SIGNAL(regist(QString)), socket, SLOT(sendMsg(QString)));
	//connect(g, SIGNAL(make(QString)), socket, SLOT(sendMsg(QString)));
	connect(room, SIGNAL(make(QString)), socket, SLOT(sendMsg(QString)));

	socket->moveToThread(thread);
	thread->start();
}

void MainFrame::initData()
{
	// �̶����ڴ�С
	this->setMinimumSize(600, 600);	// ������С�ߴ�
	this->setMaximumSize(600, 600);	// �������ߴ�
	this->setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);	//��ֹ���
	this->setConnection();

}

void MainFrame::setConnection()
{

	connect(ui.pvp_Button, SIGNAL(clicked()), this, SLOT(pvp()));
	connect(ui.pve_Button, SIGNAL(clicked()), this, SLOT(pve()));
	connect(ui.Online_Button, SIGNAL(clicked()), this, SLOT(online()));
	connect(ui.Sign_Button, SIGNAL(clicked()), this, SLOT(Sign()));
	connect(ui.Exit_Button, SIGNAL(clicked()), this, SLOT(exit()));
	connect(ui.music_button, SIGNAL(clicked()), this, SLOT(music()));
	connect(g, SIGNAL(back_to()), this, SLOT(menu()));
	connect(l, SIGNAL(back()), this, SLOT(reshow()));
	connect(room, SIGNAL(back()), this, SLOT(reshow()));
	//connect(room, SIGNAL(back()), this, SLOT(reshow()));
	
}

void MainFrame::pvp() //�� ���˶�ս����
{
	room->hide();
	this->hide();
	g->show();
}
void MainFrame::exit()//�˳�����
{
	qApp->quit();//���ص�¼�Ի���  
				  //emit quit();//�����˳��ź� 
}

void MainFrame::music()
{
	PlaySound(LPWSTR(IDR_WAVE1), GetModuleHandle(NULL), SND_RESOURCE | SND_ASYNC | SND_LOOP);
	
	
	//QMessageBox::information(this, "��ʾ", "���ڿ�����");
}

void MainFrame::online()//ͨ����������/��¼����
{
	this->hide();//���ص�¼�Ի���  
	room->show(); 
}

void MainFrame::Sign()//ͨ����¼��ťֱ�ӵ�¼����
{
	this->hide();//���ص�¼�Ի��� 
	l->show();//emit quit();//�����˳��ź�
}

void MainFrame::reshow()//���´򿪽���
{
	l->hide();
	room->hide();
	this->show();
}

void MainFrame::processReq(QStringList list)
{
	int req = list.at(0).toInt();

	if (req == MATCH_SUCC)
		pvp();

}

void MainFrame::menu()
{
	g->hide();
	this->show();
}
