// cmanager.cpp
#include "cmanager.h"

CManager::CManager()
{
}

CManager::~CManager()
{
}

int CManager::getWinner(int ** checkerboard, int pos_x, int pos_y, int color)
{
	int count = 1;	// ����������¼��������ͬ������
	int x = pos_x;	// ��ǰ����x����
	int y = pos_y;	// ��ǰ����y����

/*============================����===========================*/
	// ������
	while (true)
	{
		x--;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// ���Ҽ��
	while (true)
	{
		x++;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// �ж��Ƿ���ʤ��
	if (count >= 5)
		return color;
/*============================================================*/


/*============================����============================*/
	// ����
	// ���ϼ��
	count = 1;
	while (true)
	{
		y--;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// ���Ҽ��
	while (true)
	{
		y++;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}

	if (count >= 5)
		return color;
/*============================================================*/


/*==========================���ϵ�����========================*/
	// �����ϼ��
	count = 1;
	while (true)
	{
		x--;
		y--;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// ���¼��
	while (true)
	{
		x++;
		y++;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	if (count >= 5)
		return color;
/*============================================================*/


/*==========================���ϵ�����========================*/
// �����ϼ��
	count = 1;
	while (true)
	{
		x++;
		y--;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// �����¼��
	while (true)
	{
		x--;
		y++;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	if (count >= 5)
		return color;
/*============================================================*/

	return 0;
}

void CManager::SaveBoard(QVector<ChessNode> chesses)
{
	ofstream out("savedboard.data");

	if (!out)
		QMessageBox::information(NULL, "��ʾ", "��Ǹ���������ʧ�ܣ�����");
	else
	{
		//out << chesses[0].pixmap;
	}
}

void CManager::ReadBoard()
{
}

// ������Ϣ
QString CManager::getEncryptInfo(ChessNode * chessInfo)
{
	QString str = QString::number(chessInfo->color) + "|" +
		QString::number(chessInfo->i) + "|" +
		QString::number(chessInfo->j);

	return str;
}

// ������Ϣ
void CManager::parseInfo(QString str_msg)
{
	QStringList list = str_msg.split("|");

	chess->color = list.at(0).toInt();
	chess->i = list.at(1).toInt();
	chess->j = list.at(2).toInt();

	list.clear();
}
