// Log.cpp
#include "Log.h"

// ���캯��
Log::Log(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	this->initData();	// ��ʼ������
}

// ��ʼ������
void Log::initData()
{
	// �̶����ڴ�С
	this->setMinimumSize(600, 600);	// ������С�ߴ�
	this->setMaximumSize(600, 600);	// �������ߴ�
	this->setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);	//��ֹ���
	this->regHide();
	this->setConnection();
}

// �����ź���۵�����
void Log::setConnection()
{
	connect(ui.login_button, SIGNAL(clicked()), this, SLOT(log()));
	connect(ui.exit_button, SIGNAL(clicked()), this, SLOT(Return()));
	connect(ui.signin_button, SIGNAL(clicked()), this, SLOT(regShow()));
	connect(ui.back_button, SIGNAL(clicked()), this, SLOT(regHide()));
	connect(ui.register_button, SIGNAL(clicked()), this, SLOT(sign_in()));
}

void Log::log()
{
	
}

void Log::Return()
{
	emit back();
}

void Log::regHide()
{
	ui.nickname_label->hide();
	ui.nickname_edit->hide();
	ui.confirm_edit->hide();
	ui.confirm_label->hide();
	ui.back_button->hide();
	ui.register_button->hide();

	ui.login_button->show();
	ui.signin_button->show();
	ui.exit_button->show();
}

void Log::regShow()
{
	ui.nickname_label->show();
	ui.nickname_edit->show();
	ui.confirm_edit->show();
	ui.confirm_label->show();
	ui.back_button->show();
	ui.register_button->show();

	ui.login_button->hide();
	ui.signin_button->hide();
	ui.exit_button->hide();
}

void Log::sign_in()
{
	QString str_msg  =	QString::number(SIGN_IN) + "|" +
						ui.account_edit->text() + "|" +
						ui.password_edit->text() + "|" +
						ui.nickname_edit->text();
	qDebug() << "�������� ��" << str_msg;
	//emit regist(str_msg);
}

void Log::makeRoom(QString msg)
{
	emit regist(msg);
}
