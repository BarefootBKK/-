// Onlinepvp.cpp
#include "Onlinepvp.h"

#include"chessboard.h"

// ���캯��
Onlinepvp::Onlinepvp(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	this->initData();	// ��ʼ������
}

// ��ʼ������
void Onlinepvp::initData()
{
	// �̶����ڴ�С
	this->setMinimumSize(1250, 900);	// ������С�ߴ�
	this->setMaximumSize(1250, 900);	// �������ߴ�
	this->setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);	//��ֹ���
	this->setConnection();

	manager = new CManager();
	
}

// �����ź���۵�����
void Onlinepvp::setConnection()
{
	connect(ui.checkerboard_label, SIGNAL(clicked()), this, SLOT(drawChess()));
	connect(ui.checkerboard_label, SIGNAL(chessed()), this, SLOT(sendChessInfo()));
	connect(ui.undo_Button, SIGNAL(clicked()), this, SLOT(undo()));
	connect(ui.defeat_Button, SIGNAL(clicked()), this, SLOT(defeat()));
	connect(ui.save_Button, SIGNAL(clicked()), this, SLOT(save()));
}

// ������
void Onlinepvp::drawChess()
{
	ui.checkerboard_label->Draw();
}

void Onlinepvp::undo()
{
	ui.checkerboard_label->Undo();
	ui.checkerboard_label->Undo();
}

void Onlinepvp::defeat() {

}


void Onlinepvp::sendChessInfo()
{
	emit boardMsg(manager->getEncryptInfo(ui.checkerboard_label->GetChessInfo()));
}

void Onlinepvp::readChessInfo(QString chess)
{
	ui.checkerboard_label->DrawOpponent(manager->getParsedInfo(chess));
}

void Onlinepvp::save()
{
	//manager->SaveBoard(ui.checkerboard_label->GetBoardInfo());
}