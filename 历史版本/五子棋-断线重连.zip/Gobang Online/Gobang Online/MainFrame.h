#pragma once
#include <QtWidgets/QWidget>
#include <QTimer>
#include <QThread>
#include "ui_MainFrame.h"
#include "socket.h"
#include"Gobang.h"
#include"Log.h"
#include"Ranking.h"
#include"Replay.h"
#include"Onlinepvp.h"
#include"Pve.h"

class MainFrame : public QWidget
{
	Q_OBJECT

signals:
	void regist(QString);
signals:
	void reconnect();

public:
	MainFrame(QWidget *parent = Q_NULLPTR);//��������
	void initData();						// ��ʼ����������
	void setConnection();					// �����ź���۵�����

public slots:
	// �ۺ���
	void online();
	void exit();
	void pvp();
	void pve();
	void menu();
	void Sign();
	void music();
	void replayBoard();
	void ranking();
	void reshow();
	void processReq(QStringList);
	void loginState();
	void reconnThread();
	void startReconn();
	void setConnState(bool);

private:
	Ui::FormMain ui;
	
	Gobang *gobang;
	Log *log;
	Room * room;
	Ranking	*rank;
	Replay *replay;
	Onlinepvp*pvponline;
	Pve* pvew;
	Socket * socket;
	QThread * reconn_thread;
	QTimer * c_timer;
	bool isLogIn = false;
	bool isConnected;
};
