// cmanager.h

class CManager
{
public:
	CManager();
	~CManager();

public:
	int getWinner(int **, int, int);
	int getWinner(int **, int, int, int);
};