// cmanager.cpp
#include "cmanager.h"

CManager::CManager()
{
}

CManager::~CManager()
{
}

int CManager::getWinner(int ** m_data, int x, int y)
{
	if (m_data[x][y] == 2 && x + 1 < 15 && m_data[x + 1][y] == 2 && m_data[x + 2][y] == 2 && m_data[x + 3][y] == 2 && m_data[x + 4][y] == 2)//ˮƽ���Ҽ�����
		return 2;
	else if (m_data[x][y] == 1 && x + 1 < 15 && m_data[x + 1][y] == 1 && m_data[x + 2][y] == 1 && m_data[x + 3][y] == 1 && m_data[x + 4][y] == 1)//ˮƽ���Ҽ�����
		return 1;

	else if (m_data[x][y] == 2 && x - 1 > 0 && m_data[x - 1][y] == 2 && m_data[x - 2][y] == 2 && m_data[x - 3][y] == 2 && m_data[x - 4][y] == 2)//ˮƽ���������
		return 2;
	else if (m_data[x][y] == 1 && x - 1 > 0 && m_data[x - 1][y] == 1 && m_data[x - 2][y] == 1 && m_data[x - 3][y] == 1 && m_data[x - 4][y] == 1)//ˮƽ���������
		return 1;

	else if (m_data[x][y] == 2 && y + 1 < 15 && m_data[x][y + 1] == 2 && m_data[x][y + 2] == 2 && m_data[x][y + 3] == 2 && m_data[x][y + 4] == 2)//��ֱ���¼�����
		return  2;
	else if (m_data[x][y] == 1 && y + 1 < 15 && m_data[x][y + 1] == 1 && m_data[x][y + 2] == 1 && m_data[x][y + 3] == 1 && m_data[x][y + 4] == 1)//��ֱ���¼�����
		return 1;

	else if (m_data[x][y] == 2 && y - 1 > 0 && m_data[x][y - 1] == 2 && m_data[x][y - 2] == 2 && m_data[x][y - 3] == 2 && m_data[x][y - 4] == 2)//��ֱ���ϼ�����
		return 2;
	else if (m_data[x][y] == 1 && y - 1 > 0 && m_data[x][y - 1] == 1 && m_data[x][y - 2] == 1 && m_data[x][y - 3] == 1 && m_data[x][y - 4] == 1)//��ֱ���ϼ�����
		return 1;

	else if (m_data[x][y] == 2 && x + 1 <15 && m_data[x + 1][y + 1] == 2 && m_data[x + 2][y + 2] == 2 && m_data[x + 3][y + 3] == 2 && m_data[x + 4][y + 4] == 2)//���Ϸ�������
		return 2;
	else if (m_data[x][y] == 1 && x + 1 < 15 && m_data[x + 1][y + 1] == 1 && m_data[x + 2][y + 2] == 1 && m_data[x + 3][y + 3] == 1 && m_data[x + 4][y + 4] == 1)//���Ϸ�������
		return 1;

	else if (m_data[x][y] == 2 && x - 1 > 0 && m_data[x - 1][y + 1] == 2 && m_data[x - 2][y + 2] == 2 && m_data[x - 3][y + 3] == 2 && m_data[x - 4][y + 4] == 2)//���Ϸ�������
		return 2;
	else if (m_data[x][y] == 1 && x - 1 > 0 && m_data[x - 1][y + 1] == 1 && m_data[x - 2][y + 2] == 1 && m_data[x - 3][y + 3] == 1 && m_data[x - 4][y + 4] == 1)//���Ϸ�������
		return 1;

	else if (m_data[x][y] == 2 && x + 1 < 15 && m_data[x + 1][y - 1] == 2 && m_data[x + 2][y - 2] == 2 && m_data[x + 3][y - 3] == 2 && m_data[x + 4][y - 4] == 2)//���·�������
		return 2;
	else if (m_data[x][y] == 1 && x + 1 < 15 && m_data[x + 1][y - 1] == 1 && m_data[x + 2][y - 2] == 1 && m_data[x + 3][y - 3] == 1 && m_data[x + 4][y - 4] == 1)//���·�������
		return 1;

	else if (m_data[x][y] == 2 && x - 1 > 0 && m_data[x - 1][y - 1] == 2 && m_data[x - 2][y - 2] == 2 && m_data[x - 3][y - 3] == 2 && m_data[x - 4][y - 4] == 2)//���·�������
		return 2;
	else if (m_data[x][y] == 1 && x - 1 > 0 && m_data[x - 1][y - 1] == 1 && m_data[x - 2][y - 2] == 1 && m_data[x - 3][y - 3] == 1 && m_data[x - 4][y - 4] == 1)//���·�������
		return 1;
	else
		return 0;
}


int CManager::getWinner(int ** checkerboard, int pos_x, int pos_y, int color)
{
	int count = 1;	// ����������¼��������ͬ������
	int x = pos_x;	// ��ǰ����x����
	int y = pos_y;	// ��ǰ����y����

/*============================����===========================*/
	// ������
	while (true)
	{
		x--;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// ���Ҽ��
	while (true)
	{
		x++;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// �ж��Ƿ���ʤ��
	if (count == 5)
		return color;
/*============================================================*/


/*============================����============================*/
	// ����
	// ���ϼ��
	count = 1;
	while (true)
	{
		y--;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// ���Ҽ��
	while (true)
	{
		y++;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}

	if (count == 5)
		return color;
/*============================================================*/


/*==========================���ϵ�����========================*/
	// �����ϼ��
	count = 1;
	while (true)
	{
		x--;
		y--;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// ���¼��
	while (true)
	{
		x++;
		y++;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	if (count == 5)
		return color;
/*============================================================*/


/*==========================���ϵ�����========================*/
// �����ϼ��
	count = 1;
	while (true)
	{
		x++;
		y--;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	// �����¼��
	while (true)
	{
		x--;
		y++;
		if (x < 0 || y < 0 || x > 14 || y > 14)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		else if (checkerboard[x][y] != color)
		{
			x = pos_x;
			y = pos_y;
			break;
		}
		count++;
	}
	if (count == 5)
		return color;
/*============================================================*/

	return 0;
}
