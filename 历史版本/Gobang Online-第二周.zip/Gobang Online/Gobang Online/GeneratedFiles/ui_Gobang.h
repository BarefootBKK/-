/********************************************************************************
** Form generated from reading UI file 'Gobang.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GOBANG_H
#define UI_GOBANG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>
#include <checkerboardlabel.h>

QT_BEGIN_NAMESPACE

class Ui_GobangClass
{
public:
    CheckerboardLabel *checkerboard_label;
    QPushButton *undo_button;
    QPushButton *restart_button;

    void setupUi(QWidget *GobangClass)
    {
        if (GobangClass->objectName().isEmpty())
            GobangClass->setObjectName(QStringLiteral("GobangClass"));
        GobangClass->resize(1400, 900);
        GobangClass->setStyleSheet(QStringLiteral(""));
        checkerboard_label = new CheckerboardLabel(GobangClass);
        checkerboard_label->setObjectName(QStringLiteral("checkerboard_label"));
        checkerboard_label->setGeometry(QRect(50, 40, 814, 814));
        checkerboard_label->setStyleSheet(QStringLiteral("background-image: url(:/Gobang/Image/Chess/bg.jpg);"));
        checkerboard_label->setAlignment(Qt::AlignCenter);
        undo_button = new QPushButton(GobangClass);
        undo_button->setObjectName(QStringLiteral("undo_button"));
        undo_button->setGeometry(QRect(1080, 657, 171, 61));
        QFont font;
        font.setFamily(QString::fromUtf8("\346\226\271\346\255\243\345\247\232\344\275\223"));
        font.setPointSize(18);
        undo_button->setFont(font);
        undo_button->setCursor(QCursor(Qt::PointingHandCursor));
        restart_button = new QPushButton(GobangClass);
        restart_button->setObjectName(QStringLiteral("restart_button"));
        restart_button->setGeometry(QRect(1080, 760, 171, 61));
        restart_button->setFont(font);
        restart_button->setCursor(QCursor(Qt::PointingHandCursor));

        retranslateUi(GobangClass);

        QMetaObject::connectSlotsByName(GobangClass);
    } // setupUi

    void retranslateUi(QWidget *GobangClass)
    {
        GobangClass->setWindowTitle(QApplication::translate("GobangClass", "Gobang", Q_NULLPTR));
        checkerboard_label->setText(QString());
        undo_button->setText(QApplication::translate("GobangClass", "\346\202\224\346\243\213", Q_NULLPTR));
        restart_button->setText(QApplication::translate("GobangClass", "\351\207\215\346\226\260\345\274\200\345\247\213", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class GobangClass: public Ui_GobangClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GOBANG_H
