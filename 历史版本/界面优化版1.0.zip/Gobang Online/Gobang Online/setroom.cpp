// setroom.cpp
#include "setroom.h"

SetRoomDialog::SetRoomDialog(QWidget * parent)
	: QDialog(parent)
{
	ui.setupUi(this);

	initData();
}

void SetRoomDialog::initData()
{
	this->roomType = ROOM_PU;
	ui.setKey_label->hide();
	ui.key_edit->hide();

	connect(ui.okButton, SIGNAL(clicked()), this, SLOT(finishSet()));
	connect(ui.type_checkBox, SIGNAL(stateChanged(int)), this, SLOT(setKey(int)));
}

void SetRoomDialog::setKey(int state)
{
	if (state == Qt::Checked)
	{
		roomType = ROOM_PR;
		ui.setKey_label->show();
		ui.key_edit->show();
	}
	else if (state == Qt::Unchecked)
	{
		roomType = ROOM_PU;
		ui.setKey_label->hide();
		ui.key_edit->hide();
	}
}

void SetRoomDialog::finishSet()
{
	if (ui.roomname_edit->text().length() < 1)
	{
		this->show();
		QMessageBox::information(NULL, "Hint", "Please type in Room-Name !");
	}
	else
	{
		QString str_msg = QString::number(roomType) + "|" +
							ui.roomname_edit->text();
		if (roomType == ROOM_PR)
			str_msg = str_msg + "|" + ui.key_edit->text();
		else
			str_msg = str_msg + "|" + "-1001";

		emit roomInfo(str_msg);

		ui.roomname_edit->setText("");
		ui.key_edit->setText("");
		ui.type_checkBox->setCheckState(Qt::Unchecked);

	}
}
