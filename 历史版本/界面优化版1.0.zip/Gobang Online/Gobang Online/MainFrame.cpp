#include"MainFrame.h"
#include<windows.h>  

#include<mmsystem.h>  
#pragma comment(lib,"winmm.lib")  
#include"resource.h"

#include <QMessageBox>

MainFrame::MainFrame(QWidget *parent)
	: QWidget(parent)
{
	gobang = new Gobang();
	log = new Log();
	room = new Room();
	rank = new Ranking();
	pvew = new Pve();
	replay = new Replay();
	pvponline = new Onlinepvp();

	ui.setupUi(this);
	this->initData();	// ��ʼ������

	QThread * thread = new QThread();
	socket = new Socket(Q_NULLPTR, "192.168.2.170", 8080);
	connect(socket, SIGNAL(readyRead()),	socket, SLOT(on_read()));
	connect(socket, SIGNAL(connected()),	socket, SLOT(on_connection()));
	connect(socket, SIGNAL(disconnected()), socket, SLOT(on_disconnection()));
	connect(socket, SIGNAL(serv_msg(QStringList)), this, SLOT(processReq(QStringList)));
	connect(socket, SIGNAL(serv_msg(QStringList)), room, SLOT(updateRoomList(QStringList)));
	connect(socket, SIGNAL(oppChess(QString)), gobang, SLOT(readChessInfo(QString)));
	connect(socket, SIGNAL(serv_msg(QStringList)), log, SLOT(analyzeMsg(QStringList)));
	connect(log, SIGNAL(log_msg(QString)), socket, SLOT(sendMsg(QString)));
	connect(room, SIGNAL(room_msg(QString)), socket, SLOT(sendMsg(QString)));
	connect(gobang, SIGNAL(boardMsg(QString)), socket, SLOT(sendMsg(QString)));

	socket->moveToThread(thread);
	thread->start();
}

void MainFrame::initData()
{
	// �̶����ڴ�С
	this->setMinimumSize(600, 600);	// ������С�ߴ�
	this->setMaximumSize(600, 600);	// �������ߴ�
	this->setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);	//��ֹ���
	this->setConnection();

}

void MainFrame::setConnection()
{
	connect(ui.pvp_Button, SIGNAL(clicked()), this, SLOT(pvp()));
	connect(ui.pve_Button, SIGNAL(clicked()), this, SLOT(pve()));
	connect(ui.Online_Button, SIGNAL(clicked()), this, SLOT(online()));
	connect(ui.Sign_Button, SIGNAL(clicked()), this, SLOT(Sign()));
	connect(ui.Exit_Button, SIGNAL(clicked()), this, SLOT(exit()));
	connect(ui.replay_Button, SIGNAL(clicked()), this, SLOT(replayBoard()));
	connect(ui.ranking_Button, SIGNAL(clicked()), this, SLOT(ranking()));
	connect(ui.music_button, SIGNAL(clicked()), this, SLOT(music()));
	connect(gobang, SIGNAL(back_to()), this, SLOT(menu()));
	connect(log, SIGNAL(back()), this, SLOT(reshow()));
	connect(pvew, SIGNAL(back_to()), this, SLOT(menu()));
	connect(log, SIGNAL(log_in()), this, SLOT(loginState()));
	connect(room, SIGNAL(back()), this, SLOT(reshow()));
	connect(rank, SIGNAL(back()), this, SLOT(reshow()));
	connect(replay, SIGNAL(back()), this, SLOT(reshow()));
	
}

void MainFrame::pvp() //�� ���˶�ս����
{
	this->hide();
	gobang->setPattern(PVP_LOCAL);
	gobang->show();
}

void MainFrame::pve() 
{
	this->hide();
	gobang->setPattern(PVE);
	gobang->show();
}

void MainFrame::exit()	//�˳�����
{
	qApp->quit();		//�˳�����
}

void MainFrame::music()
{
	//QMessageBox::information(this, "��ʾ", "���ڿ�����");
}

void MainFrame::online()//ͨ����������/��¼����
{
	if (!isLogIn)
	{
		this->hide();//���ص�¼�Ի���  
		room->show();
	}
	else
		Sign();
}

void MainFrame::Sign()//ͨ����¼��ťֱ�ӵ�¼����
{
	this->hide();//���ص�¼�Ի��� 
	log->show();//emit quit();//�����˳��ź�
}

void MainFrame::replayBoard()
{
	this->hide();//���ص�¼�Ի��� 
	replay->show();//emit quit();//�����˳��ź�
}

void MainFrame::ranking()//ͨ����¼��ťֱ�ӵ�¼����
{
	this->hide();//���ص�¼�Ի��� 
	rank->show();//emit quit();//�����˳��ź�
}
void MainFrame::reshow()//���´򿪽���
{
	log->hide();
	room->hide();
	replay->hide();
	rank->hide();
	pvew->hide();
	this->show();
}

void MainFrame::processReq(QStringList list)
{
	int req = list.at(0).toInt();

	if (req == MATCH_SUCC || req == ROOM_ADD_SUCC) {
		room->hide();
		this->hide();
		pvponline->show();
	}
		
	else if (req == ROOM_KEY_ERROR)
		QMessageBox::information(NULL, "hint", "�����������");
}

void MainFrame::loginState()
{
	isLogIn = true;
	ui.log_state_label->setText("�ѵ�¼");
}

void MainFrame::menu()
{
	pvew->hide();
	gobang->hide();
	this->show();
}
