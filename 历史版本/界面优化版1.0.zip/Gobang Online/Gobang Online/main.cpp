// main.cpp
#include "Gobang.h"
#include"MainFrame.h"
#include <QtWidgets/QApplication>
#include <QStyleFactory>

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	//Gobang w;
	MainFrame w;
	QApplication::setStyle(QStyleFactory::create("fusion"));	//���ô��ڷ��
	//Gobang w;
	w.show();
	return a.exec();
}
