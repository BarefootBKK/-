
#include <QtWidgets/QWidget>
#include "ui_createroom.h"
#include <globalVal.h>
#include <QMessageBox>

class SetRoomDialog : public QDialog
{
	Q_OBJECT

signals:
	void roomInfo(QString);

public:
	SetRoomDialog(QWidget *parent = Q_NULLPTR);	// ���캯��

	void initData();

private slots:
	void setKey(int);
	void finishSet();

private:
	Ui::SetRoomDialog ui;
	int roomType;
};