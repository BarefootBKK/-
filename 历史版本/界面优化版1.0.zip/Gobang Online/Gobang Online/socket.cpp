// socket.cpp
#include "socket.h"

Socket::Socket(QObject * parent, QString ip, int port)
	: QTcpSocket(parent)
{
	this->isMatched = false;
	this->abort();
	this->connectToHost(ip, port);

	if (!this->waitForConnected(3000))
	{
		qDebug() << "connect failed !";
		this->disconnectFromHost();
	}

	qDebug() << "connect successfully !";
}

void Socket::on_connection()
{
	emit conn();
}

void Socket::on_disconnection()
{
	emit discon();
}

void Socket::on_read()
{
	QByteArray buffer = this->readAll();

	QString str_msg = QString::fromLocal8Bit(buffer);

	if (!buffer.isEmpty())
	{
		if (isMatched)
			oppChess(tr(buffer));
		else
			phraseMsg(str_msg);
	}
}

void Socket::sendMsg(QString str_msg)
{
	this->write(str_msg.toLocal8Bit());
	this->waitForBytesWritten();
	this->flush();
}

void Socket::phraseMsg(QString msg)
{
	QStringList list = msg.split("|");
	int req = list.at(0).toInt();

	if (req == MATCH_SUCC || req == ROOM_ADD_SUCC)
		this->isMatched = true;

	emit serv_msg(list);
}