// Log.cpp
#include "Room.h"

#include <QMessageBox>
#include"qdebug.h"
//#include"MainFrame.h"


 // ���캯��
Room::Room(QWidget *parent)
	: QWidget(parent)
{
	ui.setupUi(this);
	
	this->initData();	// ��ʼ������
}

// ��ʼ������
void Room::initData()
{
	this->setRoomDialog = new SetRoomDialog();
	// �̶����ڴ�С
	this->setMinimumSize(600, 600);	// ������С�ߴ�
	this->setMaximumSize(600, 600);	// �������ߴ�
	this->setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);	//��ֹ���
	this->setConnection();

	ui.tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);//��ֹ�༭����
	ui.tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);//���ñ���Ϊѡ������
}

// �����ź���۵�����
void Room::setConnection()
{
	connect(ui.match_button, SIGNAL(clicked()), this, SLOT(matching()));
	connect(ui.create_Button, SIGNAL(clicked()), this, SLOT(create()));
	connect(ui.return_Button, SIGNAL(clicked()), this, SLOT(Return()));
	connect(setRoomDialog, SIGNAL(roomInfo(QString)), this, SLOT(set(QString)));
	connect(ui.tableWidget, SIGNAL(cellDoubleClicked(int, int)), this, SLOT(joinRoom(int,int)));
}

void Room::matching()
{
	if (!isMatching)
	{
		isMatching = true;
		emit room_msg(QString::number(MATCH));
		ui.match_button->setText("ȡ��ƥ��");
		ui.create_Button->setEnabled(false);
	}
	else
	{
		emit room_msg(QString::number(MATCH_CANCEL));
		ui.match_button->setText("ƥ�����");
		ui.create_Button->setEnabled(true);
	}
}

void Room::Return()
{
	emit back();
}

void Room::create()
{
	setRoomDialog->setModal(true);
	setRoomDialog->show();
}

void Room::set(QString msg)
{
	emit room_msg(msg);
}

void Room::updateRoomList(QStringList list)//�����б�����ı�
{
		if (list.at(0).toInt() == ROOM_NEW)
		{
			// ��������
			ui.tableWidget->setRowCount(list.length() - 1);

			for (int i = 1; i < list.length(); i++)
			{
				QStringList item_list = list.at(i).split("!");
				
				ui.tableWidget->setItem(i - 1, 0, new QTableWidgetItem(item_list.at(0)));
				ui.tableWidget->setItem(i - 1, 1, new QTableWidgetItem(item_list.at(1)));
				ui.tableWidget->setItem(i - 1, 2, new QTableWidgetItem(getRoomType(item_list.at(2).toInt())));
				ui.tableWidget->setItem(i - 1, 3, new QTableWidgetItem(QString(item_list.at(3)) + "/2"));

				for (int j = 0; j < 4; j++)
					ui.tableWidget->item(i - 1, j)->setTextAlignment(Qt::AlignCenter);
			}
		}
	
}

void Room::joinRoom(int row, int column)
{
	int player_num = ui.tableWidget->item(row, 3)->text().toInt();

	if (player_num < 2)
	{
		QString room_num = ui.tableWidget->item(row, 1)->text();
		QString room_type = ui.tableWidget->item(row, 2)->text();
		QString room_key;

		if (room_type == "����")
		{
			bool ok;
			QInputDialog dialog;
			dialog.setWindowModality(Qt::WindowModal);
			QString temp_key = dialog.getText(this, tr("��������"), tr("�뷿�����룺"),
				QLineEdit::Normal, NULL, &ok);

			if (ok && !temp_key.isEmpty())
				room_key = temp_key;
		}
		else
			room_key = QString::number(-1001);

		QString roomMsg = QString::number(ROOM_ADD) + "|" +
							room_num + "|" + room_key;

		emit room_msg(roomMsg);
	}
}

QString Room::getRoomType(int room_int_type)
{
	if (room_int_type == ROOM_PU)
		return "����";
	else
		return "����";
}
