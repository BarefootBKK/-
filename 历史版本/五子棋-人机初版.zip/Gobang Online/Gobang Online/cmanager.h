// cmanager.h
// ����
#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")
#endif

#ifndef _CMANAGER_H_
#define _CMANAGER_H_

#include <fstream>
#include <iostream>
#include <QVector>
#include <QMessageBox>
#include "globalVal.h"

using namespace std;

class CManager
{
public:
	CManager();
	~CManager();

public:
	int getWinner(int **, int, int, int);
	void SaveBoard(QVector<ChessNode>);
	void ReadBoard();
	QString getEncryptInfo(ChessNode *);
	void parseInfo(QString);

private:
	ChessNode * chess;
};
#endif