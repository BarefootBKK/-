//// ai_bot.h
//#include "ai_bot.h"
//
//AIBot::AIBot(int my_chess)
//{
//	this->my_chess = my_chess;
//	this->rival_chess = getRival(my_chess);
//
//	pos = new PosNode();
//	pos->x = 0;
//	pos->y = 0;
//	pos->socre = 0;
//
//	initScoreTable();	// ��ʼ����ֵ��
//}
//
//// ��ʼ����ֵ��
//void AIBot::initScoreTable()
//{
//	memset(&score_table, 0, BOARD_SIZE * BOARD_SIZE);
//}
//
//// ai��ʼ˼��
//void AIBot::startThinking(int ** board)
//{
//	int value = 0;
//
//	int line[6][17];
//
//	// ��ֹԽ��
//	for (int i = 0; i < 6; i++)
//		line[i][0] = line[i][16] = OVER_BOARD;
//
//	for (int i = 0; i < BOARD_SIZE; i++)
//	{
//		int line_num = 1;
//
//		// ��ά����תһά
//		for (int j = 0; j < BOARD_SIZE; j++, line_num++)
//		{
//			line[0][line_num] = getPosState(board, i, j);		// "|"
//			line[1][line_num] = getPosState(board, j, i);		// "��"
//			line[2][line_num] = getPosState(board, i + j, j);	// "\"
//			line[3][line_num] = getPosState(board, i - j, j);	// "/"
//			line[4][line_num] = getPosState(board, j, i + j);	// "\"
//			line[5][line_num] = getPosState(board, BOARD_SIZE - j - 1, i + j);	// "/"
//		}
//		// �����ߵ�״̬�� �ж��Ƿ�Ϊ�Խ������� 
//		int line_state = i == 0 ? 4 : 6;
//
//		for (int p = 0; p < line_state; p++);
//
//	}
//
//}
//
//// ��ȡ������
//int AIBot::evaluateLine(int * line)
//{
//	int value = 0;
//
//	for (int i = 0; i < BOARD_SIZE; i++)
//	{
//		if (line[i] == my_chess)	// �ҵ�һ���ҷ�����
//		{
//			int cnt = 1;
//			int dlk = 0;
//
//			if (line[i - 1] == OVER_BOARD) dlk++;
//
//			for (i = i + 1; i < BOARD_SIZE && line[i] == my_chess; i++, cnt++);
//
//			if (line[i] == rival_chess) dlk++;
//
//			value += getValue(cnt, dlk);
//		}
//	}
//
//	return value;
//}
//
//// ��ȡ��ֵ
//int AIBot::getValue(int cnt, int dlk)
//{
//	if (dlk == 0)		// û��Χ��
//	{
//		switch (cnt)
//		{
//		case 1: return L_ONE;
//		case 2: return L_TWO;
//		case 3: return L_THREE;
//		case 4: return L_FOUR;
//		defult: return B_FIVE;
//		}
//	}
//	else if (dlk == 1)	// ����Χ��
//	{
//		switch (cnt)
//		{
//		case 1: return D_ONE;
//		case 2: return D_TWO;
//		case 3: return D_THREE;
//		case 4: return D_FOUR;
//		defult: return B_FIVE;
//		}
//	}
//	else				// ˫��Χ��
//	{
//		if (cnt >= 5)	
//			return B_FIVE;
//		else
//			return ZERO;
//	}
//}
//
//// ��ȡĳһ����λ��״̬
//int AIBot::getPosState(int ** board, int x, int y)
//{
//	// �ж��Ƿ�Խ��
//	if (x >= 0 && x < BOARD_SIZE && y >= 0 && y < BOARD_SIZE)
//	{
//		if (board[x][y] == my_chess)
//		{
//			return my_chess;
//		}
//		else if (board[x][y] == rival_chess)
//		{
//			return rival_chess;
//		}
//		else
//		{
//			return NONE;
//		}
//	}
//	else
//		return rival_chess;
//}
//
//// ��ȡ����������ɫ
//int AIBot::getRival(int color)
//{
//	if (color == BLACK)
//		return WHITE;
//	else
//		return BLACK;
//}
//
//// ��ȡ����xλ��
//int AIBot::GetPosX()
//{
//	return pos->x;
//}
//
//// ��ȡ����yλ��
//int AIBot::GetPosY()
//{
//	return pos->y;
//}