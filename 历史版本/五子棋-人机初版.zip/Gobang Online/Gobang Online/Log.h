
#pragma once
#if _MSC_VER >= 1600
#pragma execution_character_set("utf-8")
#endif
#include <QtWidgets/QWidget>
#include <QThread>
#include "ui_Log.h"
#include"Room.h"
#include "socketthread.h"
#include "socket.h"
#include "globalVal.h"

class Log : public QWidget
{
	Q_OBJECT

signals:
	void back();
signals:
	void regist(QString);

public:
	Log(QWidget *parent = Q_NULLPTR);		// ���캯��
	void initData();						// ��ʼ����������
	void setConnection();					// �����ź���۵�����


public slots:
	// �ۺ���
	void log();
	void Return();
	void regHide();
	void regShow();
	void sign_in();
	void makeRoom(QString);

	//void sendsignal();

private:
	Ui::FormLog ui;
};